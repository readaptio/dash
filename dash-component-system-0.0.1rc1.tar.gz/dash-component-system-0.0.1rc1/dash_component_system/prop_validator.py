
class Validator(object):
    def __init__(self, component_type):
        pass

    def validate(self, prop_type, ):
        pass
