class MissingPropError(TypeError):
    pass
